import { Component } from '@angular/core';

@Component({
  selector: 'app-carga-masiva-usuarios',
  imports: [],
  templateUrl: './carga-masiva-usuarios.html',
  styleUrl: './carga-masiva-usuarios.scss'
})
export class CargaMasivaUsuariosComponent {

}
