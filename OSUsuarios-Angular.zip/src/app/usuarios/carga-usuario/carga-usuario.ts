import { Component } from '@angular/core';

@Component({
  selector: 'app-carga-usuario',
  imports: [],
  templateUrl: './carga-usuario.html',
  styleUrl: './carga-usuario.scss'
})
export class CargaUsuarioComponent {

}
