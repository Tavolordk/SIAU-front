import { Component } from '@angular/core';

@Component({
  selector: 'app-olvido-contrasena',
  imports: [],
  templateUrl: './olvido-contrasena.html',
  styleUrl: './olvido-contrasena.scss'
})
export class OlvidoContrasenaComponent {

}
