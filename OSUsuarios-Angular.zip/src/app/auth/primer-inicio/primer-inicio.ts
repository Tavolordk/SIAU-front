import { Component } from '@angular/core';

@Component({
  selector: 'app-primer-inicio',
  imports: [],
  templateUrl: './primer-inicio.html',
  styleUrl: './primer-inicio.scss'
})
export class PrimerInicioComponent {

}
