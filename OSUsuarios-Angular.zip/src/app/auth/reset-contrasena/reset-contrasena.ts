import { Component } from '@angular/core';

@Component({
  selector: 'app-reset-contrasena',
  imports: [],
  templateUrl: './reset-contrasena.html',
  styleUrl: './reset-contrasena.scss'
})
export class ResetContrasenaComponent {

}
