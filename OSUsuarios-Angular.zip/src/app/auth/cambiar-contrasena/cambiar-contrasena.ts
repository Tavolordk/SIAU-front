import { Component } from '@angular/core';

@Component({
  selector: 'app-cambiar-contrasena',
  imports: [],
  templateUrl: './cambiar-contrasena.html',
  styleUrl: './cambiar-contrasena.scss'
})
export class CambiarContrasenaComponent {

}
