import { Component } from '@angular/core';
import { NavMenuComponent } from '../nav-menu/nav-menu';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-main-layout',
  imports: [NavMenuComponent, RouterOutlet],
  templateUrl: './main-layout.html',
  styleUrl: './main-layout.scss'
})
export class MainLayoutComponent {

}
