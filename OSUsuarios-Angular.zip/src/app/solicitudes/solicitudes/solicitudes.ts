import { Component } from '@angular/core';

@Component({
  selector: 'app-solicitudes',
  imports: [],
  templateUrl: './solicitudes.html',
  styleUrl: './solicitudes.scss'
})
export class SolicitudesComponent {

}
